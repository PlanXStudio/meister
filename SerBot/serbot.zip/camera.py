import socket
import struct
import threading
import numpy as np
import cv2

def apply_text_outline(frame):
    text, position, font, scale, color, thickness, line_type = "Serbot, World!", (10, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA
    cv2.putText(frame, text, position, font, scale, (0, 0, 0), thickness + 4, line_type)
    cv2.putText(frame, text, position, font, scale, color, thickness, line_type)
    
    return frame

class Camera:
    MAX_DGRAM = 2**16

    def __init__(self, multicast_group='224.1.1.1', port=5000, **kwargs):

        self.mcast_recv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.mcast_recv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.mcast_recv.bind(('', port))

        mreq = struct.pack("4sl", socket.inet_aton(multicast_group), socket.INADDR_ANY)
        self.mcast_recv.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

        self.frame = None
        self.is_stoped = False
        self.th = threading.Thread(target=self.on_mcast_recv_loop, daemon=True)
        self.th.start()

    def __del__(self):
        self.is_stoped = True
        self.th.join()
        self.mcast_recv.close()

    def on_mcast_recv_loop(self):
        while not self.is_stoped:
            data, _ = self.mcast_recv.recvfrom(Camera.MAX_DGRAM)
                    
            self.frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
                    
    def read(self):
        return self.frame