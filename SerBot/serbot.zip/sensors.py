from smbus2 import SMBus

class IMU:
    """
    MPU6050
    address = 0x68
    bus = 1
    """
    
    MPU_CONFIG          = 0x1A
    GYRO_CONFIG         = 0x1B
    ACCEL_CONFIG        = 0x1C
                       
    ACCEL_X_H           = 0x3B
    ACCEL_Y_H           = 0x3D
    ACCEL_Z_H           = 0x3F
    TEMP                = 0x41
    GYRO_X_H            = 0x43
    GYRO_Y_H            = 0x45
    GYRO_Z_H            = 0x47

    PWR_MGMT_1          = 0x6B
    
    ACCEL_RANGE_2G      = 0x00 #000xxx
    ACCEL_RANGE_4G      = 0x08 #001xxx
    ACCEL_RANGE_8G      = 0x10 #010xxx
    ACCEL_RANGE_16G     = 0x18 #011xxx
   
    GYRO_RANGE_250DEG   = 0x00
    GYRO_RANGE_500DEG   = 0x08
    GYRO_RANGE_1000DEG  = 0x10
    GYRO_RANGE_2000DEG  = 0x18

    ACCEL_SCALE = {
        ACCEL_RANGE_2G:16384.0,
        ACCEL_RANGE_4G:8192.0,
        ACCEL_RANGE_8G:4096.0,
        ACCEL_RANGE_16G:2048.0
    }

    GYRO_SCALE = {
        GYRO_RANGE_250DEG:131.0,
        GYRO_RANGE_500DEG:65.5,
        GYRO_RANGE_1000DEG:32.8,
        GYRO_RANGE_2000DEG:16.4
    }
    
    GRAVITIY_MS2 = 9.80665 # m/s^2


    def __init__(self, addr=0x68, bus=1):
        self.__addr = addr
        self.__bus = SMBus(bus)
        
        self.__bus.write_byte_data(self.__addr, self.PWR_MGMT_1, 0x00)

    def __del__(self):
        self.__bus.close() 

    def __read_word_data(self, reg):
        high = self.__bus.read_byte_data(self.__addr, reg)
        value = (high << 8) | self.__bus.read_byte_data(self.__addr, reg + 1)
        
        return value if (value <= 32768) else value - 65536

    def getAccelRange(self):
        return self.__bus.read_byte_data(self.__addr, self.ACCEL_CONFIG)

    def setAccelRange(self, range):
        self.__bus.write_byte_data(self.__addr, self.ACCEL_CONFIG, 0)
        self.__bus.write_byte_data(self.__addr, self.ACCEL_CONFIG, range)
        
    def getGyroRange(self):
        return self.__bus.read_byte_data(self.__addr, self.GYRO_CONFIG)

    def setGyroRange(self, range):
        self.__bus.write_byte_data(self.__addr, self.GYRO_CONFIG, 0)
        self.__bus.write_byte_data(self.__addr, self.GYRO_CONFIG, range)

    def setFilterRange(self, range):
        ext_sync_set = self.__bus.read_byte_data(self.__addr, self.MPU_CONFIG) & 0b00111000
        self.__bus.write_byte_data(self.__addr, self.MPU_CONFIG,  ext_sync_set | range)

    def getTemp(self, cal=-10):
        raw_temp = self.__read_word_data(self.TEMP)

        return ((raw_temp / 340.0) + 36.53 + cal)

    def getAccel(self, gravity=False):
        range = self.getAccelRange()
        scale = self.ACCEL_SCALE[range]

        x = self.__read_word_data(self.ACCEL_X_H) / scale
        y = self.__read_word_data(self.ACCEL_Y_H) / scale
        z = self.__read_word_data(self.ACCEL_Z_H) / scale

        if not gravity:
            x *= self.GRAVITIY_MS2
            y *= self.GRAVITIY_MS2
            z *= self.GRAVITIY_MS2

        return (x, y, z)

    def getGyro(self):
        range = self.getGyroRange()
        scale = self.GYRO_SCALE[range]
                
        x = self.__read_word_data(self.GYRO_X_H) / scale
        y = self.__read_word_data(self.GYRO_Y_H) / scale
        z = self.__read_word_data(self.GYRO_Z_H) / scale
        
        return (x, y, z)

