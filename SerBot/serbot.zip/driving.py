"""
3-Wheel Omni-Wheel Drive Controller
"""

import math
import time
from typing import Optional, Tuple
from smbus2 import SMBus


class PWM:
    # PCA9685 Registers
    MODE1     = 0x00
    PRESCALE  = 0xFE
    LED0_ON_L = 0x06
    CLOCK     = 25_000_000.0  # 25 MHz

    def __init__(self, addr: int = 0x40, bus: int = 0, freq: int = 1000):
        """Initialize I²C bus and set PWM frequency (40–1000Hz recommended)."""
        self._addr = addr
        self._bus = SMBus(bus)
        self.reset()
        self.set_freq(freq)

    def reset(self) -> None:
        """Reset PCA9685 MODE1 register."""
        self._bus.write_byte_data(self._addr, self.MODE1, 0x00)
        time.sleep(5e-4)

    def set_freq(self, freq: int) -> None:
        """
        Set PWM frequency in Hz.
        Clamped to safe range: 40–1000 Hz.
        """
        freq = max(40, min(freq, 1000))
        prescale = int(round(self.CLOCK / (4096.0 * freq) - 1))
        old = self._bus.read_byte_data(self._addr, self.MODE1)
        # Enter sleep to set prescale
        self._bus.write_byte_data(self._addr, self.MODE1, (old & 0x7F) | 0x10)
        self._bus.write_byte_data(self._addr, self.PRESCALE, prescale)
        # Restart
        self._bus.write_byte_data(self._addr, self.MODE1, old)
        time.sleep(5e-4)
        self._bus.write_byte_data(self._addr, self.MODE1, old | 0xA1)

    def set_duty(self, channel: int, duty: float) -> None:
        """
        Set duty cycle (0.0–100.0%) on channel 0–15.
        Internally converts to 12-bit OFF count.
        """
        duty = max(0.0, min(duty, 100.0))
        off_count = int(round(duty * 40.95))  # 4095/100
        base = self.LED0_ON_L + 4 * channel
        # ON=0, OFF=off_count
        self._bus.write_i2c_block_data(
            self._addr,
            base,
            [0x00, 0x00, off_count & 0xFF, off_count >> 8]
        )

    def close(self) -> None:
        """Close the I²C bus."""
        self._bus.close()

    def __enter__(self) -> "PWM":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


class Driver(PWM):
    """
    Abstraction for 3 DC motors (H-bridge per motor on two channels).
    Duty -100..100 → direction + magnitude.
    """
    CHANNEL_PAIR = (0, 2, 4)
    STOP, CW, CCW = 0, 1, -1

    def __init__(self, **pwm_kw) -> None:
        super().__init__(**pwm_kw)
        self._duty = [0.0, 0.0, 0.0]
        self._dir = [self.STOP, self.STOP, self.STOP]

    def wheel(self, idx: int, duty: float) -> None:
        """
        Control wheel idx (0–2) with signed duty (-100..100).
        Positive = CW, Negative = CCW.
        """
        assert 0 <= idx < 3
        ch = self.CHANNEL_PAIR[idx]
        duty = max(-100.0, min(duty, 100.0))

        if duty == 0.0:
            self._duty[idx] = 0.0
            self._dir[idx] = self.STOP
            self.set_duty(ch, 0.0)
            self.set_duty(ch + 1, 0.0)
        else:
            self._duty[idx] = abs(duty)
            if duty > 0:
                self._dir[idx] = self.CW
                self.set_duty(ch, duty)
                self.set_duty(ch + 1, 0.0)
            else:
                self._dir[idx] = self.CCW
                self.set_duty(ch, 0.0)
                self.set_duty(ch + 1, abs(duty))

    def stop(self) -> None:
        """Emergency stop: all wheels to 0 duty."""
        for i in range(3):
            self.wheel(i, 0.0)

    @property
    def duty(self) -> Tuple[float, float, float]:
        return tuple(self._duty)

    @property
    def direction(self) -> Tuple[int, int, int]:
        return tuple(self._dir)


class Driving(Driver):
    """
    High-level kinematics for 3-wheel omni platform.
    Supports move(angle), forward/backward with steering, and spin in place.
    """
    WHEEL_ANGLE    = (-60.0, 60.0, 180.0)  # degrees (0° = front)
    STEERING_LIMIT = 45.0                  # max ± steering offset (°)

    def __init__(self, min_throttle: float = 25.0, **pwm_kw) -> None:
        super().__init__(**pwm_kw)
        self._throttle = max(0.0, min(min_throttle, 100.0))
        self._steering = 0.0
        self._mode = 'stop'

    @property
    def throttle(self) -> float:
        return self._throttle

    @throttle.setter
    def throttle(self, v: float) -> None:
        self._throttle = max(0.0, min(v, 100.0))

    @property
    def steering(self) -> float:
        return self._steering

    @steering.setter
    def steering(self, v: float) -> None:
        assert -1.0 <= v <= 1.0
        self._steering = v
        if self._mode in ('fwd', 'bwd'):
            self._apply_steering()

    def _apply_steering(self) -> None:
        """
        Recompute movement during forward/backward with current steering.
        """
        base = 0.0 if self._mode == 'fwd' else 180.0
        offset = self._steering * self.STEERING_LIMIT
        speeds = self._inverse_kin(base + offset, self._throttle)
        for i, sp in enumerate(speeds):
            self.wheel(i, sp)

    def _inverse_kin(self, angle: float, v: float) -> Tuple[float, float, float]:
        """
        Pure translation inverse kinematics.
        angle: heading in degrees (clockwise positive),
        v: speed magnitude 0..100
        """
        rad = math.radians(angle)
        vx = v * math.cos(rad)
        vy = v * math.sin(rad)
        speeds: list[float] = []
        for phi_deg in self.WHEEL_ANGLE:
            phi = math.radians(phi_deg)
            wi = vx * math.sin(phi) - vy * math.cos(phi)
            speeds.append(wi)
        return tuple(max(-100.0, min(s, 100.0)) for s in speeds)

    def move(self, angle: float, throttle: Optional[float] = None) -> None:
        """
        Move in heading angle (0° = front), optional throttle 0..100.
        angle positive = clockwise (right).
        """
        if throttle is not None:
            self.throttle = throttle
        if self.throttle == 0.0:
            self.stop()
            return

        speeds = self._inverse_kin(angle, self._throttle)
        for i, sp in enumerate(speeds):
            self.wheel(i, sp)
        self._mode = 'move'

    def forward(self, throttle: Optional[float] = None) -> None:
        if throttle is not None:
            self.throttle = throttle
        self._mode = 'fwd'
        self._apply_steering()

    def backward(self, throttle: Optional[float] = None) -> None:
        if throttle is not None:
            self.throttle = throttle
        self._mode = 'bwd'
        self._apply_steering()

    def spin_left(self, throttle: Optional[float] = None) -> None:
        """Spin in place left: all wheels CW."""
        if throttle is not None:
            self.throttle = throttle
        for i in range(3):
            self.wheel(i, self._throttle)
        self._mode = 'spin'

    def spin_right(self, throttle: Optional[float] = None) -> None:
        """Spin in place right: all wheels CCW."""
        if throttle is not None:
            self.throttle = throttle
        for i in range(3):
            self.wheel(i, -self._throttle)
        self._mode = 'spin'

    def stop(self) -> None:
        self._mode = 'stop'
        super().stop()
